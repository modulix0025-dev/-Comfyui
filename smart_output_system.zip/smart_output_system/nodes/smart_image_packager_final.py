"""
SmartImagePackagerFinal — collects up to 30 validated image paths and packs
them into an atomic zip. All heavy logic lives in core.packager_core.
"""

from ..core.packager_core import build_packager_input_types, run_packager

IMAGE_EXTS = {".png", ".jpg", ".jpeg"}


class SmartImagePackagerFinal:
    @classmethod
    def INPUT_TYPES(cls):
        return build_packager_input_types(strict_default=True)

    RETURN_TYPES  = ("STRING", "STRING", "INT")
    RETURN_NAMES  = ("zip_path", "download_url", "file_count")
    FUNCTION      = "package"
    CATEGORY      = "SmartPackager"
    OUTPUT_NODE   = True

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")  # always re-execute — pure function semantics

    def package(self, strict_mode=True, **kwargs):
        zp, url, count = run_packager(
            kwargs,
            allowed_exts=IMAGE_EXTS,
            sub_dir="smart_image_package",
            zip_basename="images.zip",
            strict_mode=bool(strict_mode),
        )
        return (zp, url, int(count))


NODE_CLASS_MAPPINGS         = {"SmartImagePackagerFinal": SmartImagePackagerFinal}
NODE_DISPLAY_NAME_MAPPINGS  = {"SmartImagePackagerFinal": "Smart Image Packager (Final)"}
