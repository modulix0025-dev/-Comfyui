"""
SmartVideoPackagerFinal — collects up to 30 validated video paths and packs
them into an atomic zip. All heavy logic lives in core.packager_core.
"""

from ..core.packager_core import build_packager_input_types, run_packager

VIDEO_EXTS = {".mp4", ".webm", ".mov"}


class SmartVideoPackagerFinal:
    @classmethod
    def INPUT_TYPES(cls):
        return build_packager_input_types(strict_default=True)

    RETURN_TYPES  = ("STRING", "STRING", "INT")
    RETURN_NAMES  = ("zip_path", "download_url", "file_count")
    FUNCTION      = "package"
    CATEGORY      = "SmartPackager"
    OUTPUT_NODE   = True

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")

    def package(self, strict_mode=True, **kwargs):
        zp, url, count = run_packager(
            kwargs,
            allowed_exts=VIDEO_EXTS,
            sub_dir="smart_video_package",
            zip_basename="videos.zip",
            strict_mode=bool(strict_mode),
        )
        return (zp, url, int(count))


NODE_CLASS_MAPPINGS         = {"SmartVideoPackagerFinal": SmartVideoPackagerFinal}
NODE_DISPLAY_NAME_MAPPINGS  = {"SmartVideoPackagerFinal": "Smart Video Packager (Final)"}
