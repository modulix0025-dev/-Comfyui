"""
SmartSaveImageMegaNode — Production-grade 30-slot visual dashboard save node.

CORE CONTRACT (UNCHANGED — guaranteed by the upgrade):
    * 30 optional IMAGE inputs           (image_01 .. image_30)
    * 30 STRING outputs (full paths)     (image_path_01 .. image_path_30)
    * Deterministic filenames            (slide_01.png .. slide_30.png)
    * Always OVERWRITES (no increment, no random suffix, no prefix input)
    * SYNC behavior : if a slot receives no input this run, the previously
      saved file is preserved AND its path is still returned.

UPGRADE (frontend sync):
    In addition to the standard `ui.images` payload, this node now emits a
    structured `ui.slot_dashboard` array so the web extension can drive a
    true visual dashboard. For every one of the 30 slots:

        {
            "slot":        1..30,
            "state":       "filled" | "empty",
            "filename":    "slide_XX.png",            (always present)
            "subfolder":   "smart_save_image",        (filled only)
            "type":        "output",                  (filled only)
            "updated_now": bool                       (True iff re-saved THIS run)
        }

    `updated_now` lets the frontend reload ONLY the thumbnails that actually
    changed (performance optimization), while still rendering all 30 rows.

EXECUTION RELIABILITY FIXES (this revision):
    * IS_CHANGED now returns float("nan") — NaN != NaN, so ComfyUI's cache
      hash comparison ALWAYS misses and the node is re-queued every run.
      This is the canonical idiom for defeating the output-node cache
      (the previous `return ""` was a constant hash → "unchanged" → node
      skipped, which is why nothing appeared in the Generates panel).
    * Detailed debug logging per run and per slot so execution can be
      verified at a glance in the ComfyUI console.
    * Defensive tensor handling that never crashes on None / empty / odd
      shapes / non-contiguous arrays / unexpected dtypes.

NO external dependencies beyond ComfyUI's own stack.
"""

from __future__ import annotations

import os
import traceback

import numpy as np
from PIL import Image

import folder_paths

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NUM_SLOTS: int = 30
IMAGE_SUBFOLDER: str = "smart_save_image"
FILENAME_TEMPLATE: str = "slide_{:02d}.png"

LOG_TAG: str = "[SmartSaveImageMega]"


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------

class SmartSaveImageMegaNode:
    """Mega-dashboard save node for up to 30 images."""

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #
    def __init__(self) -> None:
        self.output_dir: str = folder_paths.get_output_directory()
        self.target_dir: str = os.path.join(self.output_dir, IMAGE_SUBFOLDER)
        os.makedirs(self.target_dir, exist_ok=True)

    # ------------------------------------------------------------------ #
    # ComfyUI registration metadata
    # ------------------------------------------------------------------ #
    @classmethod
    def INPUT_TYPES(cls):
        optional = {}
        for i in range(1, NUM_SLOTS + 1):
            optional[f"image_{i:02d}"] = ("IMAGE",)
        return {
            "required": {},
            "optional": optional,
        }

    RETURN_TYPES = tuple(["STRING"] * NUM_SLOTS)
    RETURN_NAMES = tuple(f"image_path_{i:02d}" for i in range(1, NUM_SLOTS + 1))
    FUNCTION = "save_mega"
    OUTPUT_NODE = True
    CATEGORY = "SmartOutputSystem"

    # ------------------------------------------------------------------ #
    # Cache control
    # ------------------------------------------------------------------ #
    # NaN is the canonical "always re-execute" sentinel in ComfyUI.
    # ComfyUI compares the return value of IS_CHANGED against the cached
    # value with ==. float("nan") != float("nan"), so the comparison
    # ALWAYS evaluates False, and the node is scheduled for execution on
    # every run — including when it lives downstream of a Group Executor
    # or branches that re-use cached intermediate results.
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")

    # ------------------------------------------------------------------ #
    # Low-level helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _tensor_to_pil(image_tensor):
        """
        Convert a ComfyUI IMAGE tensor [B,H,W,C] float 0..1 to a PIL image.

        Returns None on any failure / invalid input — NEVER raises.
        Handles:
            * None / empty / zero-dim tensors
            * torch tensors (via .detach().cpu().numpy())
            * numpy arrays
            * unexpected dtypes (float, int, bool, uint8)
            * grayscale (1 ch), RGB (3 ch), RGBA (4 ch), and anything wider
              (extra channels are dropped to the first 3)
            * non-contiguous arrays
        """
        if image_tensor is None:
            return None

        try:
            arr = image_tensor

            # Torch tensor → numpy
            if hasattr(arr, "detach"):
                try:
                    arr = arr.detach().cpu().numpy()
                except Exception:
                    arr = np.asarray(arr)
            elif not isinstance(arr, np.ndarray):
                arr = np.asarray(arr)

            # Guard against empty / zero-sized tensors
            if arr is None or getattr(arr, "size", 0) == 0:
                print(f"{LOG_TAG} tensor is empty; skipping")
                return None

            # Batch → first frame
            if arr.ndim == 4:
                arr = arr[0]
            # Grayscale [H,W] → [H,W,1]
            if arr.ndim == 2:
                arr = arr[..., None]
            # Reject anything that still isn't [H,W,C]
            if arr.ndim != 3:
                print(f"{LOG_TAG} unsupported tensor shape {arr.shape}; skipping")
                return None
            if arr.shape[0] == 0 or arr.shape[1] == 0:
                print(f"{LOG_TAG} tensor has a zero spatial dim {arr.shape}; skipping")
                return None

            # Coerce dtype. ComfyUI IMAGE is float 0..1; we also accept
            # already-uint8 tensors without re-scaling.
            if arr.dtype == np.uint8:
                safe = arr
            else:
                try:
                    as_float = arr.astype(np.float32, copy=False)
                except Exception:
                    as_float = np.asarray(arr, dtype=np.float32)
                safe = np.clip(as_float * 255.0, 0.0, 255.0).astype(np.uint8)

            # Ensure contiguity so PIL doesn't choke on strided views
            if not safe.flags["C_CONTIGUOUS"]:
                safe = np.ascontiguousarray(safe)

            ch = safe.shape[-1]
            if ch == 1:
                return Image.fromarray(safe[..., 0], mode="L")
            if ch == 3:
                return Image.fromarray(safe, mode="RGB")
            if ch == 4:
                return Image.fromarray(safe, mode="RGBA")
            # More than 4 channels — drop to first 3 so we never crash
            return Image.fromarray(np.ascontiguousarray(safe[..., :3]), mode="RGB")

        except Exception as exc:
            print(f"{LOG_TAG} _tensor_to_pil failed: {exc}")
            traceback.print_exc()
            return None

    def _save_png_atomic(self, image_tensor, full_path: str) -> bool:
        """Save PNG with an atomic replace. Always overwrites the destination."""
        tmp_path = full_path + ".tmp.png"
        try:
            pil = self._tensor_to_pil(image_tensor)
            if pil is None:
                # Tensor was unusable; don't touch the existing file.
                return False
            pil.save(tmp_path, "PNG", compress_level=4)
            os.replace(tmp_path, full_path)
            return True
        except Exception as exc:
            print(f"{LOG_TAG} Failed to save {full_path}: {exc}")
            traceback.print_exc()
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass
            return False

    # ------------------------------------------------------------------ #
    # Main execution
    # ------------------------------------------------------------------ #
    def save_mega(self, **kwargs):
        # Ensure dir exists even if output_directory changed mid-session
        os.makedirs(self.target_dir, exist_ok=True)

        # Summarise what we received so a user can verify from the console
        connected = [k for k in kwargs.keys() if k.startswith("image_")]
        received = sum(1 for k in connected if kwargs.get(k) is not None)
        print(f"{LOG_TAG} EXECUTING — target_dir={self.target_dir} "
              f"connected_kwargs={len(connected)} non_none={received}")

        paths: list[str] = []
        ui_images: list[dict] = []
        slot_dashboard: list[dict] = []

        saved_count = 0
        preserved_count = 0
        empty_count = 0

        for i in range(1, NUM_SLOTS + 1):
            key = f"image_{i:02d}"
            filename = FILENAME_TEMPLATE.format(i)
            full_path = os.path.join(self.target_dir, filename)

            image = kwargs.get(key, None)
            received_flag = image is not None
            updated_now = False

            if received_flag:
                if self._save_png_atomic(image, full_path):
                    updated_now = True
                    saved_count += 1
                    print(f"{LOG_TAG} Slot {i:02d}: received=True saved=True "
                          f"path={full_path}")
                else:
                    print(f"{LOG_TAG} Slot {i:02d}: received=True saved=False "
                          f"(kept old file if any)")

            exists = os.path.isfile(full_path)
            if exists:
                if not received_flag:
                    preserved_count += 1
                paths.append(full_path)
                ui_entry = {
                    "filename": filename,
                    "subfolder": IMAGE_SUBFOLDER,
                    "type": "output",
                }
                ui_images.append(ui_entry)
                slot_dashboard.append({
                    "slot": i,
                    "state": "filled",
                    "filename": filename,
                    "subfolder": IMAGE_SUBFOLDER,
                    "type": "output",
                    "updated_now": updated_now,
                })
            else:
                if not received_flag:
                    empty_count += 1
                paths.append("")
                slot_dashboard.append({
                    "slot": i,
                    "state": "empty",
                    "filename": filename,
                })

        print(f"{LOG_TAG} DONE — saved={saved_count} preserved={preserved_count} "
              f"empty={empty_count} ui_images={len(ui_images)}")

        return {
            "ui": {
                "images": ui_images,                # ComfyUI standard
                "slot_dashboard": slot_dashboard,   # Drives our custom UI
            },
            "result": tuple(paths),
        }
