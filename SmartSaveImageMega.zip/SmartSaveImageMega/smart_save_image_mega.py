"""
SmartSaveImageMegaNode — Production-grade 30-slot visual dashboard save node.

CORE CONTRACT (UNCHANGED — guaranteed by the upgrade):
    * 30 optional IMAGE inputs           (image_01 .. image_30)
    * 30 STRING outputs (full paths)     (image_path_01 .. image_path_30)
    * Deterministic filenames            (slide_01.png .. slide_30.png)
    * Always OVERWRITES (no increment, no random suffix, no prefix input)
    * SYNC behavior : if a slot receives no input this run, the previously
      saved file is preserved AND its path is still returned.

UPGRADE (frontend sync):
    In addition to the standard `ui.images` payload, this node now emits a
    structured `ui.slot_dashboard` array so the web extension can drive a
    true visual dashboard. For every one of the 30 slots:

        {
            "slot":        1..30,
            "state":       "filled" | "empty",
            "filename":    "slide_XX.png",            (always present)
            "subfolder":   "smart_save_image",        (filled only)
            "type":        "output",                  (filled only)
            "updated_now": bool                       (True iff re-saved THIS run)
        }

    `updated_now` lets the frontend reload ONLY the thumbnails that actually
    changed (performance optimization), while still rendering all 30 rows.

NO external dependencies beyond ComfyUI's own stack.
"""

from __future__ import annotations

import os
import numpy as np
from PIL import Image

import folder_paths

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NUM_SLOTS: int = 30
IMAGE_SUBFOLDER: str = "smart_save_image"
FILENAME_TEMPLATE: str = "slide_{:02d}.png"


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------

class SmartSaveImageMegaNode:
    """Mega-dashboard save node for up to 30 images."""

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #
    def __init__(self) -> None:
        self.output_dir: str = folder_paths.get_output_directory()
        self.target_dir: str = os.path.join(self.output_dir, IMAGE_SUBFOLDER)
        os.makedirs(self.target_dir, exist_ok=True)

    # ------------------------------------------------------------------ #
    # ComfyUI registration metadata
    # ------------------------------------------------------------------ #
    @classmethod
    def INPUT_TYPES(cls):
        optional = {}
        for i in range(1, NUM_SLOTS + 1):
            optional[f"image_{i:02d}"] = ("IMAGE",)
        return {
            "required": {},
            "optional": optional,
        }

    RETURN_TYPES = tuple(["STRING"] * NUM_SLOTS)
    RETURN_NAMES = tuple(f"image_path_{i:02d}" for i in range(1, NUM_SLOTS + 1))
    FUNCTION = "save_mega"
    OUTPUT_NODE = True
    CATEGORY = "SmartOutputSystem"

    # ------------------------------------------------------------------ #
    # Cache control
    # ------------------------------------------------------------------ #
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return ""

    # ------------------------------------------------------------------ #
    # Low-level helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _tensor_to_pil(image_tensor) -> Image.Image:
        """Convert a ComfyUI IMAGE tensor [B,H,W,C] float 0..1 to a PIL image."""
        arr = image_tensor
        if hasattr(arr, "detach"):
            arr = arr.detach().cpu().numpy()
        elif not isinstance(arr, np.ndarray):
            arr = np.asarray(arr)

        if arr.ndim == 4:
            arr = arr[0]
        if arr.ndim == 2:
            arr = arr[..., None]

        arr = np.clip(arr * 255.0, 0.0, 255.0).astype(np.uint8)

        if arr.shape[-1] == 1:
            return Image.fromarray(arr[..., 0], mode="L")
        if arr.shape[-1] == 3:
            return Image.fromarray(arr, mode="RGB")
        if arr.shape[-1] == 4:
            return Image.fromarray(arr, mode="RGBA")
        return Image.fromarray(arr[..., :3], mode="RGB")

    def _save_png_atomic(self, image_tensor, full_path: str) -> bool:
        """Save PNG with an atomic replace. Always overwrites the destination."""
        tmp_path = full_path + ".tmp.png"
        try:
            pil = self._tensor_to_pil(image_tensor)
            pil.save(tmp_path, "PNG", compress_level=4)
            os.replace(tmp_path, full_path)
            return True
        except Exception as exc:
            print(f"[SmartSaveImageMega] Failed to save {full_path}: {exc}")
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass
            return False

    # ------------------------------------------------------------------ #
    # Main execution
    # ------------------------------------------------------------------ #
    def save_mega(self, **kwargs):
        os.makedirs(self.target_dir, exist_ok=True)

        paths: list[str] = []
        ui_images: list[dict] = []
        slot_dashboard: list[dict] = []

        for i in range(1, NUM_SLOTS + 1):
            key = f"image_{i:02d}"
            filename = FILENAME_TEMPLATE.format(i)
            full_path = os.path.join(self.target_dir, filename)

            image = kwargs.get(key, None)
            updated_now = False

            if image is not None:
                if self._save_png_atomic(image, full_path):
                    updated_now = True

            if os.path.isfile(full_path):
                paths.append(full_path)
                ui_entry = {
                    "filename": filename,
                    "subfolder": IMAGE_SUBFOLDER,
                    "type": "output",
                }
                ui_images.append(ui_entry)
                slot_dashboard.append({
                    "slot": i,
                    "state": "filled",
                    "filename": filename,
                    "subfolder": IMAGE_SUBFOLDER,
                    "type": "output",
                    "updated_now": updated_now,
                })
            else:
                paths.append("")
                slot_dashboard.append({
                    "slot": i,
                    "state": "empty",
                    "filename": filename,
                })

        return {
            "ui": {
                "images": ui_images,                # ComfyUI standard
                "slot_dashboard": slot_dashboard,   # Drives our custom UI
            },
            "result": tuple(paths),
        }
