"""
SmartSaveVideoMegaNode — Production-grade 30-slot visual dashboard save node.

CORE CONTRACT (UNCHANGED):
    * 30 optional VIDEO inputs           (video_01 .. video_30)
    * 30 STRING outputs (full paths)     (video_path_01 .. video_path_30)
    * Deterministic filenames            (video_01.mp4 .. video_30.mp4)
    * Always OVERWRITES
    * SYNC behavior : if a slot receives no input this run, the previously
      saved file is preserved AND its path is still returned.

UPGRADE (frontend sync):
    In addition to the standard `ui.videos` / `ui.gifs` payloads, this node
    now emits a structured `ui.slot_dashboard` array so the web extension
    can drive a true visual dashboard. For every one of the 30 slots:

        {
            "slot":        1..30,
            "state":       "filled" | "empty",
            "filename":    "video_XX.mp4",
            "subfolder":   "smart_save_video",        (filled only)
            "type":        "output",                  (filled only)
            "format":      "video/mp4",               (filled only)
            "updated_now": bool                       (True iff re-saved THIS run)
        }

Video object compatibility: native ComfyUI VIDEO, VHS-style dicts, raw path
strings, objects exposing `save_to` / `get_stream_source` / `file` / `path`.
NO external dependencies beyond ComfyUI's own stack.
"""

from __future__ import annotations

import os
import shutil

import folder_paths

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

NUM_SLOTS: int = 30
VIDEO_SUBFOLDER: str = "smart_save_video"
FILENAME_TEMPLATE: str = "video_{:02d}.mp4"


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------

class SmartSaveVideoMegaNode:
    """Mega-dashboard save node for up to 30 videos."""

    # ------------------------------------------------------------------ #
    def __init__(self) -> None:
        self.output_dir: str = folder_paths.get_output_directory()
        self.target_dir: str = os.path.join(self.output_dir, VIDEO_SUBFOLDER)
        os.makedirs(self.target_dir, exist_ok=True)

    # ------------------------------------------------------------------ #
    @classmethod
    def INPUT_TYPES(cls):
        optional = {}
        for i in range(1, NUM_SLOTS + 1):
            optional[f"video_{i:02d}"] = ("VIDEO",)
        return {
            "required": {},
            "optional": optional,
        }

    RETURN_TYPES = tuple(["STRING"] * NUM_SLOTS)
    RETURN_NAMES = tuple(f"video_path_{i:02d}" for i in range(1, NUM_SLOTS + 1))
    FUNCTION = "save_mega"
    OUTPUT_NODE = True
    CATEGORY = "SmartOutputSystem"

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return ""

    # ------------------------------------------------------------------ #
    # Video saving (multi-strategy, no external deps)
    # ------------------------------------------------------------------ #
    @staticmethod
    def _resolve_path_from_dict(d: dict):
        for key in ("fullpath", "path", "filepath", "file"):
            val = d.get(key)
            if isinstance(val, str) and os.path.isfile(val):
                return val
        filename = d.get("filename")
        if isinstance(filename, str) and filename:
            folder_type = (d.get("type") or "output").lower()
            subfolder = d.get("subfolder") or ""
            base = None
            if folder_type == "output":
                base = folder_paths.get_output_directory()
            elif folder_type == "input":
                base = folder_paths.get_input_directory()
            elif folder_type == "temp":
                try:
                    base = folder_paths.get_temp_directory()
                except Exception:
                    base = None
            if base:
                candidate = os.path.join(base, subfolder, filename)
                if os.path.isfile(candidate):
                    return candidate
        return None

    def _save_video(self, video, full_path: str) -> bool:
        if video is None:
            return False

        if os.path.exists(full_path):
            try:
                os.remove(full_path)
            except Exception as exc:
                print(f"[SmartSaveVideoMega] Could not remove old file "
                      f"{full_path}: {exc}")

        save_to = getattr(video, "save_to", None)
        if callable(save_to):
            try:
                save_to(full_path)
                if os.path.isfile(full_path):
                    return True
            except Exception as exc:
                print(f"[SmartSaveVideoMega] save_to() failed: {exc}")

        gss = getattr(video, "get_stream_source", None)
        if callable(gss):
            try:
                src = gss()
                if isinstance(src, str) and os.path.isfile(src):
                    shutil.copy2(src, full_path)
                    return True
            except Exception as exc:
                print(f"[SmartSaveVideoMega] get_stream_source() failed: {exc}")

        if isinstance(video, str) and os.path.isfile(video):
            try:
                shutil.copy2(video, full_path)
                return True
            except Exception as exc:
                print(f"[SmartSaveVideoMega] copy from string path failed: {exc}")

        if isinstance(video, dict):
            src = self._resolve_path_from_dict(video)
            if src:
                try:
                    shutil.copy2(src, full_path)
                    return True
                except Exception as exc:
                    print(f"[SmartSaveVideoMega] copy from dict path failed: {exc}")

        for attr in ("file", "path", "filepath",
                     "_file", "_VideoFromFile__file", "__file"):
            if hasattr(video, attr):
                try:
                    val = getattr(video, attr)
                except Exception:
                    continue
                if isinstance(val, str) and os.path.isfile(val):
                    try:
                        shutil.copy2(val, full_path)
                        return True
                    except Exception as exc:
                        print(f"[SmartSaveVideoMega] copy from attr {attr} "
                              f"failed: {exc}")

        print(f"[SmartSaveVideoMega] Unsupported VIDEO object type: "
              f"{type(video).__name__}. Slot was skipped.")
        return False

    # ------------------------------------------------------------------ #
    # Main execution
    # ------------------------------------------------------------------ #
    def save_mega(self, **kwargs):
        os.makedirs(self.target_dir, exist_ok=True)

        paths: list[str] = []
        ui_videos: list[dict] = []
        slot_dashboard: list[dict] = []

        for i in range(1, NUM_SLOTS + 1):
            key = f"video_{i:02d}"
            filename = FILENAME_TEMPLATE.format(i)
            full_path = os.path.join(self.target_dir, filename)

            video = kwargs.get(key, None)
            updated_now = False

            if video is not None:
                if self._save_video(video, full_path):
                    updated_now = True

            if os.path.isfile(full_path):
                paths.append(full_path)
                ui_videos.append({
                    "filename": filename,
                    "subfolder": VIDEO_SUBFOLDER,
                    "type": "output",
                    "format": "video/mp4",
                })
                slot_dashboard.append({
                    "slot": i,
                    "state": "filled",
                    "filename": filename,
                    "subfolder": VIDEO_SUBFOLDER,
                    "type": "output",
                    "format": "video/mp4",
                    "updated_now": updated_now,
                })
            else:
                paths.append("")
                slot_dashboard.append({
                    "slot": i,
                    "state": "empty",
                    "filename": filename,
                })

        return {
            "ui": {
                "videos": ui_videos,
                "gifs": ui_videos,                # legacy compatibility
                "slot_dashboard": slot_dashboard,  # drives custom UI
            },
            "result": tuple(paths),
        }
