"""
SmartChainedGroupExecutor
=========================

A replacement for the stock `🎈GroupExecutor` (LAOGOU-666/Comfyui-LG_GroupExecutor)
that uses *real* data-flow connections so ComfyUI's scheduler guarantees
sequential execution order.

Why the stock node is unreliable
--------------------------------
The stock `🎈GroupExecutor` node exposes *zero* inputs and *zero* outputs
(`"inputs": [], "outputs": []` in the workflow JSON). ComfyUI builds its
execution order **exclusively from the data-flow graph** — a topological sort
of the wire connections between node outputs and inputs. A node with no wires
is an *island*: it lands in the same dependency tier as every other island,
and the scheduler is free to execute them in any order — potentially in
parallel when multiple worker threads are available.

The `order` field you can see in the workflow JSON is **LiteGraph's
client-side canvas sort hint**. It is NOT a ComfyUI runtime guarantee.
ComfyUI honours it only as a tiebreaker within a tier in single-worker mode.

The fix: add a STRING through-wire
----------------------------------
This node declares:

  * `trigger_in : STRING` (optional input, `forceInput=True`) — wire the
    previous executor's `trigger_out` here.
  * `trigger_out: STRING` (output) — emits `"done:<group_title>"` after the
    group has been triggered.

Wire a chain: A.trigger_out → B.trigger_in, B.trigger_out → C.trigger_in, ...
ComfyUI will refuse to execute B until A's output is ready, and so on.
The DAG is now linear; order is deterministic.

Triggering the actual group
---------------------------
The stock LG GroupExecutor plugin runs *inside ComfyUI's websocket loop* —
the real fire-the-group logic is client-side JavaScript that listens for
backend events. This node tries two best-effort backend paths, and will
never raise (chain integrity matters more than any single group firing):

  Method A — `server.PromptServer.instance.send_sync("balloon_group_trigger",
             {"group": <title>, "action": "execute"})`
             (per spec; forward-compatible with any plugin that listens
             on this channel.)

  Method B — `comfy_extras.nodes_group_executor.trigger_group_by_title(title)`
             (API hook some GroupExecutor variants expose.)

  Bonus    — LG GroupExecutor event fallback:
             `PromptServer.instance.send_sync("execute_group_list",
             {"group_queue": [{"group_name": title, ...}]})`
             This is the actual event name the installed LG plugin listens
             for (confirmed from its source). Left as a best-effort fallback
             so the node works out-of-the-box with the currently-installed
             plugin without changing the node's contract.

If all three fail, a warning is printed and the chain still continues via
`trigger_out`.
"""

from __future__ import annotations

import importlib
import time
import traceback

LOG_TAG = "[SmartChainedGroupExecutor]"


# ───────────────────────────────────────────────────────────────────────────
# Best-effort group trigger — never raises
# ───────────────────────────────────────────────────────────────────────────
def _trigger_group(group_title: str, repeat_count: int = 1) -> None:
    """
    Attempt to trigger the ComfyUI canvas group named `group_title`, repeated
    `repeat_count` times. Tries three approaches in order; swallows every
    exception so the chain is never broken.

    Returns: None. Success is best-effort — the caller must NOT rely on the
    group actually having run; the contract is only that the chain signal
    makes it downstream.
    """
    if not isinstance(group_title, str) or not group_title:
        print(f"{LOG_TAG} _trigger_group: empty group_title, nothing to do",
              flush=True)
        return

    try:
        rc = int(repeat_count)
    except Exception:
        rc = 1
    if rc < 1:
        rc = 1

    # ── Method A ── PromptServer balloon_group_trigger event ────────────
    method_a_ok = False
    try:
        from server import PromptServer  # type: ignore
        inst = getattr(PromptServer, "instance", None)
        if inst is not None and hasattr(inst, "send_sync"):
            for _ in range(rc):
                try:
                    inst.send_sync(
                        "balloon_group_trigger",
                        {"group": group_title, "action": "execute"},
                    )
                    method_a_ok = True
                except Exception as exc:
                    print(f"{LOG_TAG} Method A iter failed: {exc}", flush=True)
                    method_a_ok = False
                    break
    except Exception as exc:
        print(f"{LOG_TAG} Method A unavailable: {exc}", flush=True)
        method_a_ok = False

    if method_a_ok:
        return

    # ── Method B ── comfy_extras.nodes_group_executor hook ──────────────
    method_b_ok = False
    try:
        mod = importlib.import_module("comfy_extras.nodes_group_executor")
        fn = getattr(mod, "trigger_group_by_title", None)
        if callable(fn):
            for _ in range(rc):
                try:
                    fn(group_title)
                    method_b_ok = True
                except Exception as exc:
                    print(f"{LOG_TAG} Method B iter failed: {exc}", flush=True)
                    method_b_ok = False
                    break
    except Exception as exc:
        print(f"{LOG_TAG} Method B unavailable: {exc}", flush=True)
        method_b_ok = False

    if method_b_ok:
        return

    # ── Bonus ── LG plugin's actual event channel ──────────────────────
    # The installed `Comfyui-LG_GroupExecutor` plugin's frontend listens
    # for "execute_group_list" with a group_queue payload. Using it here
    # is a best-effort nicety so users with that plugin actually see their
    # groups fire — it does not change the node's contract.
    try:
        from server import PromptServer  # type: ignore
        inst = getattr(PromptServer, "instance", None)
        if inst is not None and hasattr(inst, "send_sync"):
            payload = {
                "group_queue": [
                    {
                        "group_name":    group_title,
                        "repeat_count":  rc,
                        "delay_seconds": 0,
                    }
                ]
            }
            try:
                inst.send_sync("execute_group_list", payload)
                return
            except Exception as exc:
                print(f"{LOG_TAG} Bonus fallback iter failed: {exc}",
                      flush=True)
    except Exception as exc:
        print(f"{LOG_TAG} Bonus fallback unavailable: {exc}", flush=True)

    print(f"{LOG_TAG} WARNING: all trigger methods failed for "
          f"group='{group_title}'. Chain signal will still propagate.",
          flush=True)


# ───────────────────────────────────────────────────────────────────────────
# Node
# ───────────────────────────────────────────────────────────────────────────
class SmartChainedGroupExecutor:
    """
    Chained group-executor node. Guarantees execution order via real STRING
    data-flow connections (trigger_in → trigger_out).
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "group_title":  ("STRING", {"default": "My Group"}),
                "repeat_count": ("INT",    {"default": 1, "min": 1, "max": 100}),
                "delay_ms":     ("INT",    {"default": 0, "min": 0, "max": 60000}),
            },
            "optional": {
                # forceInput=True => rendered as a REAL socket on the canvas.
                # That's what gives us the ordering guarantee.
                "trigger_in": ("STRING", {"forceInput": True}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("trigger_out",)
    FUNCTION     = "execute_group"
    OUTPUT_NODE  = True
    CATEGORY     = "SmartOutputSystem/Execution"

    # NaN != NaN → cache miss every run → node re-executes every time the
    # workflow runs, which is required since triggering groups is a side
    # effect, not a pure function.
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")

    def execute_group(self,
                      group_title: str = "My Group",
                      repeat_count: int = 1,
                      delay_ms: int = 0,
                      trigger_in: str = "") -> tuple:
        """
        Runs per-node:
          1. Log received upstream trigger.
          2. Optional pre-execution delay (delay_ms → seconds).
          3. Best-effort fire the group (`_trigger_group`).
          4. Always return `(f"done:{group_title}",)` so the downstream
             node's `trigger_in` is satisfied and the chain continues.

        NEVER raises. Chain integrity is the contract.
        """
        try:
            try:
                dmsecs = int(delay_ms)
            except Exception:
                dmsecs = 0
            if dmsecs < 0:
                dmsecs = 0

            try:
                rc = int(repeat_count)
            except Exception:
                rc = 1
            if rc < 1:
                rc = 1

            safe_title = str(group_title) if group_title is not None else ""

            print(f"{LOG_TAG} EXEC — group='{safe_title}' repeat={rc} "
                  f"delay_ms={dmsecs} trigger_in={trigger_in!r}",
                  flush=True)

            if dmsecs > 0:
                try:
                    time.sleep(dmsecs / 1000.0)
                except Exception as exc:
                    print(f"{LOG_TAG} delay sleep failed: {exc}", flush=True)

            _trigger_group(safe_title, rc)

            out = f"done:{safe_title}"
            return (out,)

        except Exception as exc:
            # Absolute backstop — we must always return a STRING so the
            # next node in the chain unblocks.
            print(f"{LOG_TAG} execute_group unexpected error: {exc}",
                  flush=True)
            try:
                traceback.print_exc()
            except Exception:
                pass
            fallback = "done:error"
            try:
                if group_title:
                    fallback = f"done:{group_title}"
            except Exception:
                pass
            return (fallback,)
