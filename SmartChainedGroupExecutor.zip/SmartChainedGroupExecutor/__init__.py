"""
SmartChainedGroupExecutor — ComfyUI custom node package.

Exposes a single node that replaces LAOGOU-666's `🎈GroupExecutor` with a
version that has real STRING data-flow connections, guaranteeing sequential
execution order under ComfyUI's scheduler (see `smart_chained_group_executor.py`
for the full explanation).
"""

from .smart_chained_group_executor import SmartChainedGroupExecutor

NODE_CLASS_MAPPINGS = {
    "SmartChainedGroupExecutor": SmartChainedGroupExecutor,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SmartChainedGroupExecutor": "Smart Chained Group Executor",
}

__all__ = [
    "NODE_CLASS_MAPPINGS",
    "NODE_DISPLAY_NAME_MAPPINGS",
]
