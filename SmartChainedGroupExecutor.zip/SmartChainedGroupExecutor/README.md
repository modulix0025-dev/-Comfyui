# SmartChainedGroupExecutor

A deterministic, data-flow-wired replacement for LAOGOU-666's
`🎈GroupExecutor` node. Fixes the execution-ordering bug where stock
GroupExecutor nodes — having no input/output wires — land in the same
scheduler tier and fire in undefined (sometimes parallel) order.

---

## Why the stock node is unreliable

The stock `🎈GroupExecutor` exposes **zero** inputs and **zero** outputs
(`"inputs": []`, `"outputs": []` in the workflow JSON).

ComfyUI builds execution order exclusively from the **data-flow graph** —
a topological sort of wire connections between node outputs and inputs.
Nodes with no wires are *islands*: they all land in the same dependency
tier and the scheduler is free to execute them in any order, sometimes
in parallel when multiple worker threads are available.

The `order` field in the workflow JSON is LiteGraph's **client-side canvas
sort hint** — it is NOT a ComfyUI runtime guarantee. ComfyUI honours it
only as a tiebreaker within a tier in single-worker mode.

**Symptom:** a workflow with 5 group executors may run them in the order
`3 → 1 → 5 → 2 → 4`, or two of them concurrently, or skip one entirely
if the scheduler short-circuits.

---

## What this node does

Adds a real STRING through-wire:

- **`trigger_in`** — optional STRING input (socket, `forceInput=True`)
- **`trigger_out`** — STRING output (socket), emits `"done:<group_title>"`

Widgets are the same three values as the stock node, just in SI units:

- `group_title` (STRING) — name of the ComfyUI canvas group to trigger
- `repeat_count` (INT, default 1) — times to fire the group
- `delay_ms` (INT, default 0) — pre-execution delay in **milliseconds**
  (stock plugin uses seconds; migration script converts automatically)

Wire chain: `A.trigger_out → B.trigger_in`, `B.trigger_out → C.trigger_in`, …
ComfyUI will refuse to execute B until A's output is ready. The DAG is
now linear; order is deterministic; parallel execution is prevented.

---

## Chain wiring diagram

```
  ┌──────────────────────┐       trigger_out (STRING)
  │  SmartChainedGroupExec │ ──────────┐
  │  group_title:  "A"   │           │
  │  repeat:   1         │           │ link id = N+1
  │  delay_ms: 0         │           ▼
  │  (no trigger_in)     │   ┌──────────────────────┐
  └──────────────────────┘   │  SmartChainedGroupExec │
                             │  group_title: "B"    │
           trigger_in  ◀─────┤  trigger_in:   IN    │
                             │  trigger_out:  OUT   │── link N+2 ──┐
                             └──────────────────────┘              │
                                                                   ▼
                                                     ┌──────────────────────┐
                                                     │  SmartChainedGroupExec │
                                                     │  group_title: "C"    │
                                                     │  (no trigger_out used)│
                                                     └──────────────────────┘
```

---

## Install

1. Copy the `SmartChainedGroupExecutor/` folder into
   `ComfyUI/custom_nodes/`.
2. Restart ComfyUI.
3. The node appears in the node picker as **Smart Chained Group Executor**
   under the category **SmartOutputSystem / Execution**.

No extra dependencies — uses only the Python standard library plus
ComfyUI's bundled `server.PromptServer`.

---

## Migrate an existing workflow

The migration script rewrites every `🎈GroupExecutor` in a workflow JSON
to a `SmartChainedGroupExecutor` and adds the chain links.

```bash
python migrate_group_executors.py  my_workflow.json  my_workflow_chained.json
```

What it does:

1. Loads the workflow.
2. Finds all `"type": "🎈GroupExecutor"` nodes, sorts them by their
   `order` field (with node `id` as a stable tiebreak).
3. Replaces each with a `SmartChainedGroupExecutor`, preserving canvas
   position / order / size, and converting:
   - `properties.groups[0]` → `group_title`
   - `properties.repeatCount` → `repeat_count` (default 1)
   - `properties.delaySeconds * 1000` → `delay_ms` (default 0)
4. Adds `inputs: []` to the first node in chain order; adds a single
   `trigger_in` input (shape 7, "optional" socket) to nodes 2..N.
5. Adds a `trigger_out` output to every node; populates its `links` with
   the outgoing link id (empty for the last node in the chain).
6. Appends one new link per consecutive pair to the top-level `links`
   array in LiteGraph row shape:
   `[link_id, src_node_id, 0, dst_node_id, 0, "STRING"]`.
7. Updates `last_link_id` and `last_node_id`.
8. Writes the result pretty-printed.
9. Prints a summary.

The source file is never modified; the destination is overwritten.

---

## How the group is actually triggered

The stock `🎈GroupExecutor` plugin is really a frontend affair — the
canvas-side JavaScript listens for backend events and drives the group.
This node tries three best-effort paths on the backend; **if every one
fails it still emits `trigger_out` so the chain is not broken**:

- **Method A** — `PromptServer.instance.send_sync("balloon_group_trigger",
  {"group": <title>, "action": "execute"})` — the channel specified in
  the node contract; future-proof for any plugin listening on it.
- **Method B** — `comfy_extras.nodes_group_executor.trigger_group_by_title(title)`
  — an API hook some GroupExecutor variants expose server-side.
- **Bonus fallback** — `PromptServer.instance.send_sync("execute_group_list",
  {"group_queue": [{"group_name": title, "repeat_count": rc, ...}]})` —
  the actual event channel the currently-installed
  `Comfyui-LG_GroupExecutor` plugin listens for. Using it here is a
  convenience so the node works end-to-end with that plugin without any
  contract change.

---

## Guarantees

- `execute_group()` **never raises**. Any internal exception is caught,
  logged, and a `"done:…"` string is still returned so the downstream
  `trigger_in` unblocks.
- `IS_CHANGED` returns `float("nan")`, so the node re-executes every
  workflow run (required, since triggering a group is a side effect,
  not a pure function).
- The node never touches the filesystem, never uses `subprocess`, never
  makes network calls. Only uses the `server` module already bundled
  with ComfyUI.

---

## Troubleshooting

### "My groups don't fire after migration"

Either:

- The installed GroupExecutor plugin expects a different event channel
  than the three this node tries, OR
- The plugin listens on a different prompt-server instance, OR
- You have the LG plugin installed but a newer build renamed its event
  channel again.

The chain ordering fix is **independent** of the trigger path — the
`trigger_in → trigger_out` wiring guarantees sequential execution even
if `_trigger_group` becomes a no-op. If groups don't fire, check the
ComfyUI console for any of these lines:

```
[SmartChainedGroupExecutor] Method A unavailable: ...
[SmartChainedGroupExecutor] Method B unavailable: ...
[SmartChainedGroupExecutor] Bonus fallback unavailable: ...
[SmartChainedGroupExecutor] WARNING: all trigger methods failed ...
```

Then add the correct event channel to `_trigger_group` in
`smart_chained_group_executor.py` as a new method — the pattern is easy
to extend.

### "The migration script renumbered my nodes"

It doesn't — node `id`s are preserved in place. Only the `last_link_id`
and `last_node_id` counters are bumped when needed; new link ids are
minted starting from `max(existing) + 1`.

### "I want to keep the old stock GroupExecutor node available"

You can — installing this node does not remove or shadow the stock
`🎈GroupExecutor`. They register under different class names. Run the
migration only on workflows where you want deterministic order.

---

## License

Same permissive license as the rest of the SmartOutputSystem bundle.
