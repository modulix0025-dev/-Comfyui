#!/usr/bin/env python3
"""
migrate_group_executors.py
==========================

Rewrites a ComfyUI workflow JSON so that every `🎈GroupExecutor` node is
replaced by a `SmartChainedGroupExecutor` node, wired into a linear chain
via a new STRING connection per consecutive pair.

USAGE
-----
    python migrate_group_executors.py  <input_workflow.json>  <output_workflow.json>

WHAT IT DOES
------------
1. Loads the workflow.
2. Finds every node with `"type": "🎈GroupExecutor"` and sorts them by
   their `order` field (with `id` as a stable tiebreak).
3. Replaces each:
     * type                → "SmartChainedGroupExecutor"
     * widgets_values      → [group_title, repeat_count, delay_ms]
                             derived from properties.groups[0],
                             properties.repeatCount, properties.delaySeconds
     * properties          → carries the same values in the dict form the
                             new node understands
     * pos / order / size  → preserved as-is
4. Sets `inputs` / `outputs` on every migrated node:
     * first node           : inputs=[], outputs=[trigger_out with links]
     * middle/last nodes    : inputs=[trigger_in with one link],
                              outputs=[trigger_out with links (none for the
                              last node)]
5. Adds one new link per consecutive pair (src.trigger_out → dst.trigger_in)
   to the top-level `links` array, using the LiteGraph link-row shape:
       [link_id, src_node_id, src_slot, dst_node_id, dst_slot, "STRING"]
6. Bumps `last_link_id` (always) and `last_node_id` (only if it was smaller
   than any node id we touched — we don't renumber nodes).
7. Writes the result pretty-printed to <output_workflow.json>.
8. Prints a summary.

NOTES
-----
* This script only *rewrites* the workflow JSON. The node package itself
  must be installed into ComfyUI separately.
* Existing non-GroupExecutor nodes and their connections are left untouched.
* Pre-existing inputs/outputs on the GroupExecutor nodes (none, in the
  stock plugin) are discarded — we fully rewrite them.
"""

from __future__ import annotations

import argparse
import json
import sys
from copy import deepcopy


# ───────────────────────────────────────────────────────────────────────────
# Constants
# ───────────────────────────────────────────────────────────────────────────
SRC_TYPE  = "🎈GroupExecutor"
DST_TYPE  = "SmartChainedGroupExecutor"
TRIG_TYPE = "STRING"


# ───────────────────────────────────────────────────────────────────────────
# Helpers
# ───────────────────────────────────────────────────────────────────────────
def _safe_get(d, key, default):
    """dict.get with default if key missing OR value is None."""
    if not isinstance(d, dict):
        return default
    v = d.get(key, default)
    return default if v is None else v


def _extract_group_title(props):
    """
    The stock 🎈GroupExecutor stores its target group name in
    properties.groups[0].name  (list of dicts)  OR  properties.groups[0]
    (list of strings, older variants)  OR  properties.group_name.
    We check all three for robustness.
    """
    if not isinstance(props, dict):
        return ""
    groups = props.get("groups")
    if isinstance(groups, list) and groups:
        first = groups[0]
        if isinstance(first, dict):
            return str(first.get("name") or first.get("group_name") or "")
        return str(first)
    return str(props.get("group_name", ""))


def _extract_repeat_count(props):
    if not isinstance(props, dict):
        return 1
    for key in ("repeatCount", "repeat_count"):
        v = props.get(key)
        if v is not None:
            try:
                n = int(v)
                return n if n >= 1 else 1
            except Exception:
                pass
    return 1


def _extract_delay_ms(props):
    """
    Stock plugin stores delay_seconds (float/int). We store delay_ms.
    Conversion: delay_ms = round(delay_seconds * 1000).
    """
    if not isinstance(props, dict):
        return 0
    # Direct delay_ms wins if present (forward-compatible)
    v = props.get("delay_ms")
    if v is not None:
        try:
            n = int(v)
            return n if n >= 0 else 0
        except Exception:
            pass
    # Fall back to delaySeconds / delay_seconds
    for key in ("delaySeconds", "delay_seconds"):
        v = props.get(key)
        if v is not None:
            try:
                n = int(round(float(v) * 1000))
                return n if n >= 0 else 0
            except Exception:
                pass
    return 0


# ───────────────────────────────────────────────────────────────────────────
# Migration
# ───────────────────────────────────────────────────────────────────────────
def migrate(workflow: dict) -> tuple[dict, int, int]:
    """
    Mutate a copy of `workflow` in place. Returns (new_workflow,
    replaced_count, chain_links_added).
    """
    wf = deepcopy(workflow)

    nodes = wf.get("nodes")
    if not isinstance(nodes, list):
        raise ValueError(
            "workflow JSON missing a top-level 'nodes' list — "
            "is this a ComfyUI LiteGraph workflow?"
        )

    links = wf.get("links")
    if not isinstance(links, list):
        links = []
        wf["links"] = links

    # ── Gather targets ────────────────────────────────────────────────
    targets = [n for n in nodes if isinstance(n, dict) and n.get("type") == SRC_TYPE]

    if not targets:
        return wf, 0, 0

    # Sort by the LiteGraph canvas `order` (primary) then `id` (stable tiebreak).
    def _sort_key(n):
        order = n.get("order")
        try:
            order_val = int(order) if order is not None else 10**9
        except Exception:
            order_val = 10**9
        try:
            id_val = int(n.get("id", 10**9))
        except Exception:
            id_val = 10**9
        return (order_val, id_val)

    targets.sort(key=_sort_key)

    # ── Compute next link id ──────────────────────────────────────────
    def _coerce_int(v, default=0):
        try:
            return int(v)
        except Exception:
            return default

    max_link_id = _coerce_int(wf.get("last_link_id", 0), 0)
    for link_row in links:
        # LiteGraph link row: [id, src_node, src_slot, dst_node, dst_slot, type]
        if isinstance(link_row, list) and link_row:
            max_link_id = max(max_link_id, _coerce_int(link_row[0], 0))

    max_node_id = _coerce_int(wf.get("last_node_id", 0), 0)
    for n in nodes:
        if isinstance(n, dict):
            max_node_id = max(max_node_id, _coerce_int(n.get("id"), 0))

    # ── Mint new chain link ids (one per consecutive pair) ────────────
    chain_links: list[list] = []
    pair_link_ids: list[int] = []

    for i in range(len(targets) - 1):
        max_link_id += 1
        src = targets[i]
        dst = targets[i + 1]
        src_id = _coerce_int(src.get("id"), 0)
        dst_id = _coerce_int(dst.get("id"), 0)
        # LiteGraph link row shape, matches what ComfyUI/LiteGraph produces.
        chain_links.append([max_link_id, src_id, 0, dst_id, 0, TRIG_TYPE])
        pair_link_ids.append(max_link_id)

    # ── Rewrite each target node ──────────────────────────────────────
    for idx, node in enumerate(targets):
        props = node.get("properties") if isinstance(node.get("properties"), dict) else {}
        group_title  = _extract_group_title(props)
        repeat_count = _extract_repeat_count(props)
        delay_ms     = _extract_delay_ms(props)

        # --- Type + properties --------------------------------------
        node["type"] = DST_TYPE

        new_props = {
            "group_title":  group_title,
            "repeat_count": repeat_count,
            "delay_ms":     delay_ms,
        }
        # Preserve any unrelated properties so users don't lose metadata.
        for k, v in props.items():
            if k not in ("groups", "group_name",
                         "repeatCount", "repeat_count",
                         "delaySeconds", "delay_seconds", "delay_ms"):
                new_props.setdefault(k, v)
        node["properties"] = new_props

        # --- widgets_values: [group_title, repeat_count, delay_ms] --
        node["widgets_values"] = [group_title, repeat_count, delay_ms]

        # --- inputs --------------------------------------------------
        if idx == 0:
            node["inputs"] = []
        else:
            in_link_id = pair_link_ids[idx - 1]  # link FROM the previous
            node["inputs"] = [
                {
                    "name":  "trigger_in",
                    "type":  TRIG_TYPE,
                    "link":  in_link_id,
                    "shape": 7,           # LiteGraph "optional" socket shape
                }
            ]

        # --- outputs -------------------------------------------------
        out_link_ids = []
        if idx < len(targets) - 1:
            out_link_ids = [pair_link_ids[idx]]  # link TO the next
        node["outputs"] = [
            {
                "name":       "trigger_out",
                "type":       TRIG_TYPE,
                "links":      out_link_ids,
                "slot_index": 0,
            }
        ]

    # ── Apply the new links + counter updates ─────────────────────────
    links.extend(chain_links)
    wf["links"] = links
    wf["last_link_id"] = max_link_id
    # Keep last_node_id at least as large as the highest node id present.
    wf["last_node_id"] = max(_coerce_int(wf.get("last_node_id", 0), 0),
                             max_node_id)

    return wf, len(targets), len(chain_links)


# ───────────────────────────────────────────────────────────────────────────
# CLI
# ───────────────────────────────────────────────────────────────────────────
def main(argv=None):
    p = argparse.ArgumentParser(
        description="Replace 🎈GroupExecutor nodes with "
                    "SmartChainedGroupExecutor and wire them into a chain.",
    )
    p.add_argument("input_path",
                   help="Source workflow JSON (unchanged on disk).")
    p.add_argument("output_path",
                   help="Destination workflow JSON (overwritten).")
    p.add_argument("--indent", type=int, default=2,
                   help="JSON pretty-print indent (default: 2).")
    args = p.parse_args(argv)

    with open(args.input_path, "r", encoding="utf-8") as f:
        workflow = json.load(f)

    new_workflow, replaced, chain_links = migrate(workflow)

    with open(args.output_path, "w", encoding="utf-8") as f:
        json.dump(new_workflow, f, indent=args.indent, ensure_ascii=False)

    print("=" * 60)
    print("SmartChainedGroupExecutor — workflow migration")
    print("=" * 60)
    print(f"  input     : {args.input_path}")
    print(f"  output    : {args.output_path}")
    print(f"  replaced  : {replaced} 🎈GroupExecutor node(s)")
    print(f"  new links : {chain_links} (chain of {replaced} → "
          f"{chain_links} consecutive pairs)")
    print(f"  last_link_id -> {new_workflow.get('last_link_id')}")
    print(f"  last_node_id -> {new_workflow.get('last_node_id')}")
    print("=" * 60)

    return 0


if __name__ == "__main__":
    sys.exit(main())
